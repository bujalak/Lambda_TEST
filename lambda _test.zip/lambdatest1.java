package lampre.lampre;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

public class lambdatest1 {
@Test
	public void lamb () {
		System.setProperty("webdriver.edge.driver",
				"C:\\Users\\KISHOREBAMMIDI\\Downloads\\edgedriver_win64\\msedgedriver.exe");
		WebDriver driver = new EdgeDriver();

		// 1.launch the URL
		driver.get("https://www.lambdatest.com/selenium-playground/");
		driver.manage().window().maximize();

		// 2.click on "simple form demo"
		WebElement option = driver.findElement(By.xpath("//a[contains(text(),'Simple Form Demo')]"));
		option.click();

		// 3.validate the URL
		String actual_url = "https://www.lambdatest.com/selenium-playground/simple-form-demo";
		String current_url = driver.getCurrentUrl();
		if (current_url.contains(actual_url)) {
			System.out.println("URL contains simple form demo");
		} else {
			System.out.println("URL do not contains simplee form demo ");
		}

		// 4.create a variable for a string value
		String text = "Welcome to LambdaTest";
         
		// 5.use this variable to enter value in the enter message text box
		WebElement textfield = driver.findElement(By.xpath("//input[@id='user-message']"));
		textfield.sendKeys(text);

		// 6.click on "get checked value"
		WebElement submit = driver.findElement(By.xpath("//button[@id='showInput']"));
		submit.click();

		// 7.validate whether the same text message is displayed in the right hand side
		WebElement textfield2 = driver.findElement(By.xpath("//p[@id='message']"));
		if (textfield2.getText().contains(text)) {
			System.out.println("Message displayed correctly");
		} else {
			System.out.println("Message does not displayed correctly");
		}
	}
}