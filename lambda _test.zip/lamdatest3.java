package lampre.lampre;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class lamdatest3 {

	public static void main(String[] args) throws InterruptedException {

		WebDriver driver;
		System.setProperty("webdriver.edge.driver",
				"C:\\Users\\KISHOREBAMMIDI\\Downloads\\edgedriver_win64\\msedgedriver.exe");
		driver = new EdgeDriver();
		driver.get("https://www.lambdatest.com/selenium-playground/");
		driver.manage().window().maximize();
		WebElement inputFormSubmit = driver.findElement(By.linkText("Input Form Submit"));
		inputFormSubmit.click();

		JavascriptExecutor Js = (JavascriptExecutor) driver;
		Js.executeScript("window.scrollBy(0,450)");

		WebElement submitButton = driver.findElement(By.xpath("//*[@id=\"seleniumform\"]/div[6]/button"));
		submitButton.click();

		// Assert "Please fill out this field."
		String errorMessage = driver.findElement(By.name("name")).getAttribute("validationMessage");

		System.out.println(errorMessage);
		Thread.sleep(3000);
		Assert.assertEquals(errorMessage, "Please fill out this field.");
		Thread.sleep(3000);
		WebElement nameField = driver.findElement(By.name("name"));
		nameField.sendKeys("Kishore");
		WebElement emailField = driver.findElement(By.id("inputEmail4"));
		emailField.sendKeys("kishore@example.com");
		WebElement phoneField = driver.findElement(By.name("password"));
		phoneField.sendKeys("Kishore5");
		WebElement companyField = driver.findElement(By.name("company"));
		companyField.sendKeys("Virtusa");

		WebElement websiteField = driver.findElement(By.name("website"));
		websiteField.sendKeys("https://www.virtusa.com/");

		Select countryDropdown = new Select(driver
				.findElement(By.xpath("/html/body/div[1]/div/section[2]/div/div/div/div/form/div[3]/div[1]/select")));
		countryDropdown.selectByVisibleText("India");

		WebElement cityField = driver.findElement(By.name("city"));
		cityField.sendKeys("Hyderabad");

		WebElement address1Field = driver.findElement(By.name("address_line1"));
		address1Field.sendKeys("Wave Rock");

		WebElement address2Field = driver.findElement(By.name("address_line2"));
		address2Field.sendKeys("Hyderabad");

		WebElement stateField = driver.findElement(By.id("inputState"));
		stateField.sendKeys("Telangana");

		WebElement zipcodeField = driver.findElement(By.id("inputZip"));
		zipcodeField.sendKeys("Telangana");

		submitButton.click();
		Thread.sleep(2000);

		WebElement successMessage = driver
				.findElement(By.xpath("//*[@id=\"__next\"]/div/section[2]/div/div/div/div/p"));
		if (successMessage.getText().equals("Thanks for contacting us, we will get back to you shortly.")) {

			System.out.println("Validation Passed: Success message displayed");
		} 
		else {
			System.out.println("Validation Failed: Success message not displayed.");
		}

		driver.quit();
	}
        }


