package lampre.lampre;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;

public class lambdatest2 {
	public static void main(String[] args) throws InterruptedException {

		WebDriver driver;
		System.setProperty("webdriver.edge.driver",
				"C:\\Users\\KISHOREBAMMIDI\\Downloads\\edgedriver_win64\\msedgedriver.exe");
		driver = new EdgeDriver();
		driver.get("https://www.lambdatest.com/selenium-playground/");
		driver.manage().window().maximize();

		WebElement slider = driver.findElement(By.linkText("Drag & Drop Sliders"));
		slider.click();

		WebElement slider15 = driver.findElement(By.xpath("//*[@id=\"slider3\"]/div/input"));
		Actions actions = new Actions(driver);
		actions.clickAndHold(slider15).moveByOffset(216, 0).release().perform();
		Thread.sleep(2000);
		WebElement rangeValue = driver.findElement(By.id("rangeSuccess"));

		if (rangeValue.getText().equals("95")) {
			System.out.println("Validation Passed: Slider set to 95.");
		}

		else {
			System.out.println("Validation Failed: Slider not set to 95.");
		}
		driver.quit();

	}

}